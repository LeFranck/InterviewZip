1)How long did you spend on the coding test? What would you add to your solution if you spent more time on it? If you didn't spend much time on the coding test then use this as an opportunity to explain what you would add.

2)What was the most useful feature that was added to Java 8? Please include a snippet of code that shows how you've used it.

3)What is your favourite framework / library / package that you love but couldn't use in the task? What do you like about it so much?

4)What great new thing you learnt about in the past year and what are you looking forward to learn more about over the next year?

5)How would you track down a performance issue in production? Have you ever had to do this? Can you add anything to your implementation to help with this?

6)How would you improve the APIs that you just used?

7)Please describe yourself in JSON format.

8)What is the meaning of life?
