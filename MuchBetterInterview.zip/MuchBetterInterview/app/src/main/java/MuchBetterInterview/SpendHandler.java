package MuchBetterInterview;

import ratpack.handling.Context;
import ratpack.handling.Handler;
import redis.clients.jedis.Jedis;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import com.fasterxml.jackson.databind.ObjectMapper;

class SpendHandler extends CommunicationHandler implements Handler {

    @Override
    void work(Context ctx, String token) {
        ctx.getRequest().getBody().then(data -> {
            String body = data.getText();
            HashMap<String, String> transaction = Util.getHashMap(body);
            HashMap<String, String> account = Util.getHashMap(ctx.get(Jedis.class).hget("users", token));
            if(transaction.get("currency").equals(account.get("currency"))){
                if (Util.isValidDate(transaction.get("date")))
                {
                    Double balance = Double.parseDouble(account.get("balance"));
                    String amount = transaction.get("amount");
                    if (Util.isNumeric(amount)){
                        Double spend_amount = Double.parseDouble(amount);
                        balance = balance - spend_amount;
                        account.put("balance", String.valueOf(balance));
                        ctx.get(Jedis.class).hset("users", token, new ObjectMapper().writeValueAsString(account));
                        //BruteForce Rewriting transactions each time
                        String transactions = ctx.get(Jedis.class).hget("transactions", token);
                        String subTransactions = transactions.substring(0, transactions.length() - 1);
                        if(subTransactions.length()>3){
                            subTransactions = subTransactions + ",";
                        }
                        String newTransactions = subTransactions + body + "]";
                        ctx.get(Jedis.class).hset("transactions", token, newTransactions);
                        ctx.getResponse().send(String.valueOf(balance));
                    }else{
                        ctx.getResponse().status(400).send("Not numeric amount");
                    }
                }else{
                    ctx.getResponse().status(400).send("Not valid date");
                }
            }else{
                ctx.getResponse().status(400).send("Unmatched currencies");
            }
        });        
    }
}
