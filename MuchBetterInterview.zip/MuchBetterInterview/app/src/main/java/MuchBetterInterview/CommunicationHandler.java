package MuchBetterInterview;

import ratpack.handling.Context;
import ratpack.handling.Handler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class CommunicationHandler implements Handler {

    public void handle(Context ctx) throws JsonMappingException, JsonProcessingException {
        String token = ctx.getRequest().getHeaders().get("Authorization");
        if(token != null){
            if(Util.accountExists(ctx, token)){
                work(ctx, token.split("Bearer ")[1]);
            }else{
                ctx.getResponse().status(404).send("That token doesn't belong to any account");
            }
        }else{
            ctx.getResponse().status(401).send("Missing Bearer Token");
        }
    }

    void work(Context ctx, String token) throws JsonMappingException, JsonProcessingException{        
    }
}
