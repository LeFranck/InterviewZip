package MuchBetterInterview;

import ratpack.handling.Context;
import ratpack.handling.Handler;
import redis.clients.jedis.Jedis;

class TransactionsHandler extends CommunicationHandler implements Handler {

    @Override
    void work(Context ctx, String token){
        ctx.getResponse().send(String.valueOf(ctx.get(Jedis.class).hget("transactions", token)));
    }

  }
