package MuchBetterInterview;

import ratpack.handling.Context;
import ratpack.handling.Handler;
import redis.clients.jedis.Jedis;

import java.util.HashMap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class BalanceHandler extends CommunicationHandler implements Handler {

    @Override
    void work(Context ctx, String token) throws JsonMappingException, JsonProcessingException {
        HashMap<String, String> account = Util.getHashMap(ctx.get(Jedis.class).hget("users", token));
        String balance = account.get("balance").toString();
        String currency = account.get("currency").toString();
        String output = "{\"balance\":"+balance+",\"currency\":\""+currency+"\"}";
        ctx.getResponse().send(output);
    }
}
