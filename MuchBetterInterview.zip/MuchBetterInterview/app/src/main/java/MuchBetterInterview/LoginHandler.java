package MuchBetterInterview;

import ratpack.handling.Context;
import ratpack.handling.Handler;
import redis.clients.jedis.Jedis;

class LoginHandler implements Handler {
  
    public void handle(Context ctx) {
        Account cuenta = new Account();
        String token = cuenta.getToken();
        ctx.get(Jedis.class).hset("users", token, cuenta.toString());
        ctx.get(Jedis.class).hset("transactions", token, "[]");
        ctx.getResponse().send(token);
    }
  }
