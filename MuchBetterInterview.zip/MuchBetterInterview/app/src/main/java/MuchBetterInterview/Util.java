package MuchBetterInterview;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ratpack.handling.Context;
import redis.clients.jedis.Jedis;

public class Util {

    public static HashMap<String, String> getHashMap(String json) throws JsonMappingException, JsonProcessingException {
        return new ObjectMapper().readValue(json, HashMap.class);
    }

    public static HashMap<String, String> getAccount(Context ctx, String bearer_token) throws JsonMappingException, JsonProcessingException {
        String account = ctx.get(Jedis.class).hget("users", bearer_token.split("Bearer ")[1]);
        return getHashMap(account);
    }

    public static boolean accountExists(Context ctx, String bearer_token){
        return null != ctx.get(Jedis.class).hget("users", bearer_token.split("Bearer ")[1]);
    }

    public static boolean isValidDate(String date){
        if(date.equals("") || date.equals(null)){
            return false;
        }

        DateTimeFormatter f = DateTimeFormatter.ISO_INSTANT;
        try {
            f.parse(date);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    public static boolean isNumeric(String amount){
        return amount.matches("-?\\d+(\\.\\d+)?");
    }

}
