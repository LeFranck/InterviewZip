package MuchBetterInterview;

import java.util.Objects;

public class Account {
    private String token;
    private double balance;
    private String currency;

    public Account() {
        RandomString session = new RandomString();
        this.token = session.nextString();
        this.balance = 1000.0;
        this.currency = "GBP";
    }

    public Account(String token, double balance, String currency) {
        this.token = token;
        this.balance = balance;
        this.currency = currency;
    }

    public String getToken() {
        return this.token;
    }

    public double getBalance() {
        return this.balance;
    }

    public String getCurrency() {
        return this.currency;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Account)) {
            return false;
        }
        Account account = (Account) o;
        return token == account.token && balance == account.balance && Objects.equals(currency, account.currency);
    }

    @Override
    public int hashCode() {
        return Objects.hash(token, balance, currency);
    }

    @Override
    public String toString() {
        return "{" +
            "\"token\":\"" + getToken() + "\"" +
            ",\"balance\":\"" + getBalance() + "\"" +
            ",\"currency\":\"" + getCurrency() + "\"" +
            "}";
    }

}
